Dot Navigation Styles
=========

A set of subtle effects and styles for simple dot navigation. 

[Article on Codrops](http://tympanus.net/codrops/?p=18295)

[Demo](http://tympanus.net/Development/DotNavigationStyles/)

Integrate or build upon it for free in your personal or commercial projects. Don't republish, redistribute or sell "as-is". 

Read more here: [License](http://tympanus.net/codrops/licensing/)


[© Codrops 2013](http://www.codrops.com)