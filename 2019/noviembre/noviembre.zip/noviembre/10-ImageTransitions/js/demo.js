$(function() {
	
	if( !Modernizr.csstransforms3d )
		$('#message').show();
	
});