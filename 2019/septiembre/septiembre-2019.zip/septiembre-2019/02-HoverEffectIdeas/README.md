Hover Effect Ideas
=========

Some inspiration and modern ideas for subtle hover effects.

[Article on Codrops](http://tympanus.net/codrops/?p=19292)

[Demo](http://tympanus.net/Development/HoverEffectIdeas/)

Images by [Unsplash](http://unsplash.com/). [Feather Icons](https://gumroad.com/l/feather) by Cole Bemis. 
[Font Awesome Icon Font] (http://fortawesome.github.io/Font-Awesome/) created by Dave Gandy.

Integrate or build upon it for free in your personal or commercial projects. Don't republish, redistribute or sell "as-is". 

Read more here: [License](http://tympanus.net/codrops/licensing/)

[© Codrops 2014](http://www.codrops.com)